"use client"

import { useState } from "react"
import { Mail, Phone, MapPin, Send, CheckCircle2 } from "lucide-react"

const contactInfo = [
  {
    icon: Mail,
    label: "Email us",
    value: "powertalks7@gmail.com",
    href: "mailto:powertalks7@gmail.com",
  },
  {
    icon: Phone,
    label: "Call us",
    value: "+91 9897907660",
    href: "tel:+919897907660",
  },
  {
    icon: MapPin,
    label: "Headquarters",
    value: "Mumbai, Maharashtra, India",
    href: "#",
  },
]

export default function Contact() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    message: "",
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormState((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    // Simulate async submission
    await new Promise((r) => setTimeout(r, 1200))
    setLoading(false)
    setSubmitted(true)
  }

  const inputClass =
    "w-full px-4 py-3 rounded-xl bg-[#0a0f24]/5 border border-border text-foreground placeholder:text-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-[#0052cc]/40 focus:border-[#0052cc] transition-all"

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-[#0052cc] font-semibold text-sm uppercase tracking-widest mb-3">
            Get in Touch
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0a0f24] tracking-tight text-balance mb-4">
            Start your free trial today
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Talk to our team or start right away. We will help you set up Optimezo for your business in under 30 minutes.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-start">
          {/* Left: contact info */}
          <div className="lg:col-span-2 flex flex-col gap-8">
            <div className="bg-[#0a0f24] rounded-2xl p-8 text-white">
              <h3 className="font-bold text-xl mb-2">Talk to Sales</h3>
              <p className="text-white/60 text-sm leading-relaxed mb-8">
                Get a personalized demo, custom pricing for your team size, and answers to all your technical questions.
              </p>

              <ul className="flex flex-col gap-5">
                {contactInfo.map((item) => {
                  const Icon = item.icon
                  return (
                    <li key={item.label} className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-[#0052cc]/20 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-[#0052cc]" />
                      </div>
                      <div>
                        <p className="text-white/50 text-xs mb-0.5">{item.label}</p>
                        <a
                          href={item.href}
                          className="text-white text-sm font-medium hover:text-[#0052cc] transition-colors"
                        >
                          {item.value}
                        </a>
                      </div>
                    </li>
                  )
                })}
              </ul>

              {/* Social links */}
              <div className="mt-8 pt-6 border-t border-white/10">
                <p className="text-white/40 text-xs mb-3 uppercase tracking-widest">Follow us</p>
                <div className="flex gap-3">
                  {[
                    { label: "LinkedIn", href: "#", letter: "in" },
                    { label: "Twitter / X", href: "#", letter: "𝕏" },
                    { label: "YouTube", href: "#", letter: "YT" },
                  ].map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      aria-label={social.label}
                      className="w-9 h-9 rounded-lg bg-white/8 hover:bg-[#0052cc] flex items-center justify-center text-white/60 hover:text-white text-xs font-bold transition-all"
                    >
                      {social.letter}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right: form */}
          <div className="lg:col-span-3">
            <div className="bg-card border border-border rounded-2xl p-8">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h3 className="text-xl font-bold text-[#0a0f24] mb-2">Message Received!</h3>
                  <p className="text-muted-foreground text-sm max-w-xs">
                    Thank you for reaching out. Our team will get back to you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate>
                  <h3 className="font-bold text-[#0a0f24] text-lg mb-6">Send us a message</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1.5">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        required
                        placeholder="Rahul Mehta"
                        value={formState.name}
                        onChange={handleChange}
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1.5">
                        Work Email <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        required
                        placeholder="rahul@company.com"
                        value={formState.email}
                        onChange={handleChange}
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-1.5">
                        Phone Number
                      </label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={formState.phone}
                        onChange={handleChange}
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label htmlFor="company" className="block text-sm font-medium text-foreground mb-1.5">
                        Company Name
                      </label>
                      <input
                        id="company"
                        name="company"
                        type="text"
                        placeholder="Mehta Textiles"
                        value={formState.company}
                        onChange={handleChange}
                        className={inputClass}
                      />
                    </div>
                  </div>
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1.5">
                      How can we help? <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      placeholder="Tell us about your business and what you're looking for..."
                      value={formState.message}
                      onChange={handleChange}
                      className={`${inputClass} resize-none`}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#0052cc] hover:bg-[#003d99] disabled:opacity-60 text-white font-semibold text-sm rounded-xl transition-all duration-200 shadow-lg shadow-[#0052cc]/20"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Sending…
                      </span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Send Message
                      </>
                    )}
                  </button>
                  <p className="text-xs text-muted-foreground text-center mt-3">
                    By submitting, you agree to our{" "}
                    <a href="#" className="text-[#0052cc] hover:underline">
                      Privacy Policy
                    </a>
                    .
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
