"use client"

import Link from "next/link"
import { ArrowRight, CheckCircle2 } from "lucide-react"
import { useEffect, useRef } from "react"

const trustPoints = [
  "No credit card required",
  "Free 14-day trial",
  "Setup in minutes",
]

/* Floating orb positions */
const orbs = [
  { size: 420, top: "-10%",  left: "50%",  delay: "0s",   dur: "14s", opacity: 0.18 },
  { size: 260, top: "60%",   left: "-5%",  delay: "2s",   dur: "11s", opacity: 0.12 },
  { size: 200, top: "20%",   left: "80%",  delay: "1.5s", dur: "9s",  opacity: 0.10 },
  { size: 140, top: "75%",   left: "70%",  delay: "3s",   dur: "13s", opacity: 0.08 },
]

/* Animated particle dots */
const particles = Array.from({ length: 20 }, (_, i) => ({
  id: i,
  left: `${5 + (i * 4.7) % 90}%`,
  bottom: `${5 + (i * 7.3) % 40}%`,
  delay: `${(i * 0.37) % 4}s`,
  duration: `${3 + (i * 0.6) % 3}s`,
  size: i % 3 === 0 ? 3 : i % 3 === 1 ? 2 : 1.5,
}))

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  /* Animated constellation canvas */
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animId: number
    const W = () => canvas.width  = canvas.offsetWidth
    const H = () => canvas.height = canvas.offsetHeight
    W(); H()

    const DOTS = 55
    const dots = Array.from({ length: DOTS }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 1.5 + 0.5,
    }))

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      for (const d of dots) {
        d.x += d.vx; d.y += d.vy
        if (d.x < 0 || d.x > canvas.width)  d.vx *= -1
        if (d.y < 0 || d.y > canvas.height) d.vy *= -1
        ctx.beginPath()
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0,130,255,0.55)"
        ctx.fill()
      }
      for (let i = 0; i < dots.length; i++) {
        for (let j = i + 1; j < dots.length; j++) {
          const dx = dots[i].x - dots[j].x
          const dy = dots[i].y - dots[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 110) {
            ctx.beginPath()
            ctx.moveTo(dots[i].x, dots[i].y)
            ctx.lineTo(dots[j].x, dots[j].y)
            ctx.strokeStyle = `rgba(0,82,204,${0.18 * (1 - dist / 110)})`
            ctx.lineWidth = 0.7
            ctx.stroke()
          }
        }
      }
      animId = requestAnimationFrame(draw)
    }
    draw()

    const onResize = () => { W(); H() }
    window.addEventListener("resize", onResize)
    return () => { cancelAnimationFrame(animId); window.removeEventListener("resize", onResize) }
  }, [])

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0a0f24]"
    >
      {/* Canvas constellation */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        aria-hidden="true"
      />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage:
            "linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)",
          backgroundSize: "72px 72px",
        }}
        aria-hidden="true"
      />

      {/* Floating glow orbs */}
      {orbs.map((orb, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none animate-float-slow"
          style={{
            width: orb.size,
            height: orb.size,
            top: orb.top,
            left: orb.left,
            transform: "translate(-50%, 0)",
            background: `radial-gradient(circle, rgba(0,82,204,${orb.opacity}) 0%, transparent 70%)`,
            animationDelay: orb.delay,
            animationDuration: orb.dur,
            filter: "blur(1px)",
          }}
          aria-hidden="true"
        />
      ))}

      {/* Floating particles */}
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full bg-[#0052cc] animate-particle pointer-events-none"
          style={{
            width: p.size,
            height: p.size,
            left: p.left,
            bottom: p.bottom,
            animationDelay: p.delay,
            animationDuration: p.duration,
          }}
          aria-hidden="true"
        />
      ))}

      {/* Spinning ring accent */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
        aria-hidden="true"
      >
        <div
          className="w-[700px] h-[700px] rounded-full border border-[#0052cc]/10 animate-spin-slow"
          style={{ animationDirection: "reverse" }}
        />
        <div
          className="absolute inset-12 rounded-full border border-[#0052cc]/8 animate-spin-slow"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20 text-center">
        {/* Pill badge */}
        <div
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/8 border border-white/15 text-white/70 text-sm font-medium mb-8 animate-slide-up"
          style={{ animationDelay: "0.1s" }}
        >
          <span className="relative flex w-2 h-2" aria-hidden="true">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0052cc] opacity-75" />
            <span className="relative inline-flex rounded-full w-2 h-2 bg-[#0052cc]" />
          </span>
          Cloud ERP &amp; Integration Platform for MSMEs
        </div>

        {/* Headline */}
        <h1
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight tracking-tight text-balance mb-6 animate-slide-up"
          style={{ animationDelay: "0.2s" }}
        >
          The Most Powerful{" "}
          <span className="gradient-text">ERP</span> for{" "}
          <span className="gradient-text">MSMEs.</span>
        </h1>

        {/* Subtext */}
        <p
          className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed mb-10 text-pretty animate-slide-up"
          style={{ animationDelay: "0.35s" }}
        >
          Run your business and connect apps seamlessly. Optimezo unifies your operations, automates workflows, and integrates with the tools you already use.
        </p>

        {/* CTA buttons */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 animate-slide-up"
          style={{ animationDelay: "0.5s" }}
        >
          <Link
            href="#contact"
            className="relative inline-flex items-center gap-2 px-8 py-3.5 bg-[#0052cc] hover:bg-[#003d99] text-white font-semibold text-base rounded-xl transition-all duration-200 shadow-lg shadow-[#0052cc]/40 hover:shadow-[#0052cc]/60 hover:scale-[1.03] group overflow-hidden"
          >
            {/* shimmer sweep */}
            <span
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{
                background:
                  "linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.18) 50%, transparent 60%)",
                backgroundSize: "200% 100%",
                animation: "shimmer 1.4s linear infinite",
              }}
              aria-hidden="true"
            />
            Get Started
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link
            href="#features"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-white/8 hover:bg-white/14 text-white font-semibold text-base rounded-xl border border-white/15 hover:border-white/30 hover:scale-[1.02] transition-all duration-200"
          >
            Explore Features
          </Link>
        </div>

        {/* Trust signals */}
        <div
          className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 animate-slide-up"
          style={{ animationDelay: "0.65s" }}
        >
          {trustPoints.map((point) => (
            <div key={point} className="flex items-center gap-1.5 text-white/50 text-sm">
              <CheckCircle2 className="w-4 h-4 text-[#0052cc]" />
              <span>{point}</span>
            </div>
          ))}
        </div>

        {/* Dashboard preview card */}
        <div
          className="mt-16 max-w-4xl mx-auto animate-slide-up animate-card-float"
          style={{ animationDelay: "0.8s" }}
        >
          <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-[#0052cc]/20 bg-[#111827] scanline">
            {/* Glow ring behind card */}
            <div
              className="absolute -inset-px rounded-2xl pointer-events-none animate-glow-pulse"
              style={{
                background:
                  "linear-gradient(135deg, rgba(0,82,204,0.3) 0%, transparent 50%, rgba(0,82,204,0.15) 100%)",
              }}
              aria-hidden="true"
            />
            {/* Browser bar */}
            <div className="flex items-center gap-2 px-4 py-3 bg-[#1a2140] border-b border-white/10">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/70" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                <div className="w-3 h-3 rounded-full bg-green-500/70" />
              </div>
              <div className="flex-1 mx-4 h-5 bg-white/8 rounded px-3 flex items-center">
                <span className="text-white/30 text-xs">app.optimezo.com/dashboard</span>
              </div>
            </div>
            {/* Dashboard content mock */}
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="h-4 w-32 bg-white/15 rounded mb-2" />
                  <div className="h-3 w-24 bg-white/8 rounded" />
                </div>
                <div className="h-8 w-24 bg-[#0052cc]/80 rounded-lg" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                {[
                  { label: "Revenue", value: "₹4.2L", change: "+12%" },
                  { label: "Orders",   value: "1,284",   change: "+8%"  },
                  { label: "Customers",value: "892",     change: "+21%" },
                  { label: "Integrations", value: "8 Live", change: "Active" },
                ].map((stat) => (
                  <div key={stat.label} className="bg-white/5 rounded-xl p-3 border border-white/8">
                    <p className="text-white/40 text-xs mb-1">{stat.label}</p>
                    <p className="text-white font-bold text-lg leading-none mb-1">{stat.value}</p>
                    <p className="text-emerald-400 text-xs font-medium">{stat.change}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-end gap-2 h-24 px-2">
                {[40,65,45,80,55,90,70,85,60,95,75,88].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t transition-all duration-700"
                    style={{
                      height: `${h}%`,
                      background:
                        i === 11
                          ? "#0052cc"
                          : `rgba(0,82,204,${0.2 + (h / 100) * 0.4})`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
