"use client"

import { useState } from "react"
import { Check, Minus, Zap, ArrowRight } from "lucide-react"
import Link from "next/link"

/* ── Plan definitions ─────────────────────────────────────── */
const plans = [
  {
    id: "free",
    name: "Free",
    tag: null,
    monthlyPrice: 0,
    annualPrice: 0,
    target: "Very small shop / evaluate",
    cta: "Get Started Free",
    ctaHref: "#contact",
    dark: false,
  },
  {
    id: "starter",
    name: "Starter",
    tag: null,
    monthlyPrice: 2499,
    annualPrice: 1999,
    target: "Small MSME replacing Excel/Tally",
    cta: "Start Free Trial",
    ctaHref: "#contact",
    dark: false,
  },
  {
    id: "growth",
    name: "Growth",
    tag: "Most Popular",
    monthlyPrice: 4999,
    annualPrice: 3999,
    target: "Growing business with teams",
    cta: "Start Free Trial",
    ctaHref: "#contact",
    dark: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    tag: null,
    monthlyPrice: 11999,
    annualPrice: 9599,
    target: "Complex multi-channel business",
    cta: "Talk to Sales",
    ctaHref: "#contact",
    dark: false,
  },
]

/* ── Feature rows ─────────────────────────────────────────── */
type Cell = string | boolean | null

interface FeatureRow {
  category?: string       // renders as a category divider row
  label?: string
  cells?: Cell[]          // aligned to [free, starter, growth, enterprise]
  highlight?: boolean
}

const rows: FeatureRow[] = [
  { category: "Limits" },
  { label: "Free trial",              cells: ["14 days (Full Starter)", false, false, false] },
  { label: "Users",                   cells: ["1 admin + 1 user", "Up to 10 users", "Up to 25 users", "Unlimited"] },
  { label: "Companies / Sites",       cells: ["1 company", "1 active site", "3 sites", "Unlimited sites"] },
  { label: "Invoices / Transactions", cells: ["100 invoices / mo", "Unlimited", "Unlimited", "Unlimited"] },
  { category: "ERP Modules" },
  { label: "Accounting & Sales",      cells: [true, true, true, true] },
  { label: "Purchases, Banking, GST", cells: [false, true, true, true] },
  { label: "CRM, Projects, Price Lists",cells: [false, false, true, true] },
  { label: "Manufacturing, HR, Payroll",cells: [false, false, false, true] },
  { category: "Inventory" },
  { label: "Basic stock (1 location)",cells: [true, true, true, true] },
  { label: "Multi-warehouse & valuation",cells:[false, false, true, true] },
  { label: "Lot tracking, serial, barcode",cells:[false, false, false, true] },
  { category: "Integrations" },
  { label: "CSV import, Gmail SMTP",  cells: [true, true, true, true] },
  { label: "Google Sheets API sync",  cells: [false, true, true, true] },
  { label: "WhatsApp (1-way), AfterShip",cells:[false, false, true, true] },
  { label: "Two-way WhatsApp, Tally, Zoho, BUSY, EasyCom",cells:[false, false, false, true] },
  { category: "API & Automation" },
  { label: "Read-only API keys",      cells: [true, true, true, true] },
  { label: "API keys (basic rate limit)",cells:[false, true, true, true] },
  { label: "Webhooks & automation",   cells: [false, false, true, true] },
  { label: "Enterprise API SLAs",     cells: [false, false, false, true] },
  { category: "Data & Onboarding" },
  { label: "Manual CSV import",       cells: [true, true, true, true] },
  { label: "CSV assistance + migration (1 hr)",cells:[false, true, true, true] },
  { label: "Migration (up to 10k records)",cells:[false, false, true, true] },
  { label: "Full migration service",  cells: [false, false, false, true] },
  { label: "Onboarding call / sessions",cells:["Self-guided","1× 1-hr call","2× sessions","Dedicated"] },
  { category: "Support" },
  { label: "Community + email (48–72h)",cells:[true, true, true, true] },
  { label: "Email + Chat (9–6 IST)",  cells: [false, true, true, true] },
  { label: "Priority chat (9–9 IST)", cells: [false, false, true, true] },
  { label: "Dedicated AM, Phone, 24×7",cells:[false, false, false, true] },
  { category: "Branding & Infrastructure" },
  { label: "Custom logo & colour",    cells: [false, true, true, true] },
  { label: "Custom URL / subdomain",  cells: [false, false, true, true] },
  { label: "Full white-label portal", cells: [false, false, false, true] },
  { label: "Daily backups",           cells: ["7 days", "30 days", "90 days", "Offsite SLA"] },
  { category: "Add-ons (paid)" },
  { label: "Available add-ons",       cells: ["—", "Extra migration, WhatsApp credits", "Custom connectors, SLA", "Dedicated server, custom dev"] },
]

/* ── Cell renderer ────────────────────────────────────────── */
function CellValue({ value, dark }: { value: Cell; dark: boolean }) {
  const textColor = dark ? "text-white/80" : "text-[#0a0f24]"
  const mutedColor = dark ? "text-white/30" : "text-muted-foreground"

  if (value === true)
    return <Check className={`w-4 h-4 mx-auto flex-shrink-0 ${dark ? "text-[#4d94ff]" : "text-[#0052cc]"}`} strokeWidth={2.5} />
  if (value === false)
    return <Minus className={`w-4 h-4 mx-auto flex-shrink-0 ${mutedColor}`} strokeWidth={1.5} />
  if (value === null)
    return <span className={`text-xs ${mutedColor}`}>—</span>
  return <span className={`text-xs font-medium leading-snug text-center block ${textColor}`}>{value}</span>
}

/* ── Main component ───────────────────────────────────────── */
export default function Pricing() {
  const [annual, setAnnual] = useState(false)
  const [showTable, setShowTable] = useState(false)

  return (
    <section id="pricing" className="py-24 bg-[#f7f9ff]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-[#0052cc] font-semibold text-sm uppercase tracking-widest mb-3">Pricing</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0a0f24] tracking-tight text-balance mb-4">
            Simple, transparent pricing
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Start free for 14 days. No credit card required. Upgrade anytime.
          </p>
        </div>

        {/* Toggle */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <span className={`text-sm font-medium transition-colors ${!annual ? "text-[#0a0f24]" : "text-muted-foreground"}`}>
            Monthly
          </span>
          <button
            role="switch"
            aria-checked={annual}
            onClick={() => setAnnual(!annual)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#0052cc] ${
              annual ? "bg-[#0052cc]" : "bg-border"
            }`}
          >
            <span className="sr-only">Toggle annual billing</span>
            <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform duration-200 ${annual ? "translate-x-6" : "translate-x-1"}`} />
          </button>
          <span className={`text-sm font-medium flex items-center gap-2 transition-colors ${annual ? "text-[#0a0f24]" : "text-muted-foreground"}`}>
            Annual
            <span className="inline-block px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
              Save 20%
            </span>
          </span>
        </div>

        {/* Plan cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {plans.map((plan) => {
            const price = annual ? plan.annualPrice : plan.monthlyPrice
            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl p-6 flex flex-col border transition-all duration-300 ${
                  plan.dark
                    ? "bg-[#0a0f24] border-[#0052cc] shadow-2xl shadow-[#0052cc]/20"
                    : "bg-white border-border hover:border-[#0052cc]/40 hover:shadow-lg"
                }`}
              >
                {plan.tag && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#0052cc] text-white text-xs font-bold rounded-full shadow">
                      <Zap className="w-3 h-3 fill-white" />
                      {plan.tag}
                    </span>
                  </div>
                )}

                <p className="text-[#0052cc] font-bold text-sm mb-1">{plan.name}</p>

                <div className="flex items-end gap-1 mb-1">
                  {price === 0 ? (
                    <span className={`text-3xl font-bold tracking-tight ${plan.dark ? "text-white" : "text-[#0a0f24]"}`}>
                      Free
                    </span>
                  ) : (
                    <>
                      <span className={`text-3xl font-bold tracking-tight ${plan.dark ? "text-white" : "text-[#0a0f24]"}`}>
                        ₹{price.toLocaleString("en-IN")}
                      </span>
                      <span className={`text-xs mb-1.5 ${plan.dark ? "text-white/50" : "text-muted-foreground"}`}>/ mo</span>
                    </>
                  )}
                </div>

                <p className={`text-xs leading-relaxed mb-5 ${plan.dark ? "text-white/50" : "text-muted-foreground"}`}>
                  {plan.target}
                </p>

                <Link
                  href={plan.ctaHref}
                  className={`mt-auto w-full py-2.5 rounded-xl font-semibold text-sm text-center transition-all duration-200 flex items-center justify-center gap-1.5 ${
                    plan.dark
                      ? "bg-[#0052cc] hover:bg-[#003d99] text-white shadow-lg shadow-[#0052cc]/30"
                      : plan.id === "free"
                      ? "bg-[#f0f4ff] hover:bg-[#0052cc] text-[#0052cc] hover:text-white border border-[#0052cc]/20 hover:border-[#0052cc]"
                      : "bg-[#e8f0fe] hover:bg-[#0052cc] text-[#0052cc] hover:text-white border border-[#0052cc]/20 hover:border-[#0052cc]"
                  }`}
                >
                  {plan.cta}
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            )
          })}
        </div>

        {/* Compare toggle */}
        <div className="text-center mb-8">
          <button
            onClick={() => setShowTable(!showTable)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#0052cc] hover:underline transition-all"
          >
            {showTable ? "Hide" : "Compare all features"}
            <ArrowRight className={`w-3.5 h-3.5 transition-transform duration-300 ${showTable ? "rotate-90" : ""}`} />
          </button>
        </div>

        {/* Full comparison table */}
        {showTable && (
          <div className="overflow-x-auto rounded-2xl border border-border shadow-sm bg-white">
            <table className="w-full min-w-[700px] text-sm border-collapse">
              {/* Sticky header */}
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-4 px-5 font-semibold text-[#0a0f24] w-[38%]">Feature</th>
                  {plans.map((plan) => (
                    <th
                      key={plan.id}
                      className={`py-4 px-3 text-center font-bold text-sm w-[15.5%] ${
                        plan.dark ? "bg-[#0a0f24] text-white" : "text-[#0a0f24]"
                      }`}
                    >
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => {
                  if (row.category) {
                    return (
                      <tr key={`cat-${i}`} className="bg-[#f0f4ff]">
                        <td
                          colSpan={5}
                          className="py-2.5 px-5 text-xs font-bold uppercase tracking-widest text-[#0052cc]"
                        >
                          {row.category}
                        </td>
                      </tr>
                    )
                  }
                  return (
                    <tr
                      key={`row-${i}`}
                      className="border-b border-border/60 hover:bg-[#f7f9ff] transition-colors"
                    >
                      <td className="py-3 px-5 text-[#0a0f24] font-medium">{row.label}</td>
                      {(row.cells ?? []).map((cell, ci) => (
                        <td
                          key={ci}
                          className={`py-3 px-3 text-center align-middle ${
                            plans[ci].dark ? "bg-[#0a0f24]/5" : ""
                          }`}
                        >
                          <CellValue value={cell} dark={false} />
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        <p className="text-center text-xs text-muted-foreground mt-6">
          All prices in INR. GST applicable. Cancel anytime. Annual billing charged upfront.
        </p>
      </div>
    </section>
  )
}
