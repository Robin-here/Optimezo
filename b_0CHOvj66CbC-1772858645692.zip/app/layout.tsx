import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Optimezo — The Most Powerful ERP for MSMEs',
  description:
    'Run your business and connect apps seamlessly. Optimezo is the cloud ERP and integration platform built for MSMEs and growing businesses.',
  keywords: [
    'ERP for MSMEs',
    'cloud ERP India',
    'business integration platform',
    'WhatsApp ERP',
    'Zoho integration',
    'AfterShip ERP',
    'BUSY accounting integration',
    'Optimezo',
  ],
  authors: [{ name: 'Optimezo' }],
  openGraph: {
    title: 'Optimezo — The Most Powerful ERP for MSMEs',
    description: 'Run your business and connect apps seamlessly.',
    type: 'website',
    url: 'https://optimezo.com',
    siteName: 'Optimezo',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Optimezo — The Most Powerful ERP for MSMEs',
    description: 'Run your business and connect apps seamlessly.',
  },
}

export const viewport: Viewport = {
  themeColor: '#0052CC',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} scroll-smooth`}>
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
