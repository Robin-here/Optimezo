import Header from "@/components/header"
import Hero from "@/components/hero"
import Features from "@/components/features"
import Integrations from "@/components/integrations"
import Pricing from "@/components/pricing"
import Testimonials from "@/components/testimonials"
import Contact from "@/components/contact"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <Features />
      <Integrations />
      <Pricing />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  )
}
