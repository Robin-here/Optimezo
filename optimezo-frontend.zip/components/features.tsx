"use client"

import {
  BarChart3,
  Package,
  Users,
  Workflow,
  ShieldCheck,
  Bell,
  FileText,
  TrendingUp,
} from "lucide-react"

const features = [
  {
    icon: BarChart3,
    title: "Real-Time Analytics",
    description: "Live dashboards tracking revenue, orders, and inventory.",
    color: "#0052cc",
  },
  {
    icon: Package,
    title: "Inventory Management",
    description: "Multi-warehouse stock sync with smart reorder alerts.",
    color: "#0f9d58",
  },
  {
    icon: Workflow,
    title: "Workflow Automation",
    description: "Automate orders, invoices, and notifications end-to-end.",
    color: "#7c3aed",
  },
  {
    icon: Users,
    title: "CRM & Customer Insights",
    description: "Centralize customer data and run targeted campaigns.",
    color: "#e55a2b",
  },
  {
    icon: FileText,
    title: "GST-Ready Invoicing",
    description: "Generate compliant invoices and file returns effortlessly.",
    color: "#0052cc",
  },
  {
    icon: TrendingUp,
    title: "Sales Pipeline",
    description: "Track leads, deals, and follow-ups in one unified view.",
    color: "#0f9d58",
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "WhatsApp, email & SMS alerts for every business event.",
    color: "#ea4335",
  },
  {
    icon: ShieldCheck,
    title: "Role-Based Access",
    description: "Enterprise-grade permissions to keep your data secure.",
    color: "#7c3aed",
  },
]

function FeatureCard({ feature }: { feature: (typeof features)[0] }) {
  const Icon = feature.icon
  return (
    <div className="flex-shrink-0 w-64 mx-3 group relative bg-white rounded-2xl border border-border p-5 hover:border-[#0052cc]/40 hover:shadow-xl hover:shadow-[#0052cc]/10 transition-all duration-300 hover:-translate-y-1 overflow-hidden cursor-default select-none">
      {/* Hover glow */}
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-2xl"
        style={{ background: `radial-gradient(circle at top left, ${feature.color}0d, transparent 70%)` }}
        aria-hidden="true"
      />
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-all duration-300 group-hover:scale-110 group-hover:rotate-3"
        style={{ background: `${feature.color}18`, color: feature.color }}
      >
        <Icon className="w-5 h-5" strokeWidth={1.75} />
      </div>
      <p className="font-semibold text-[#0a0f24] text-sm mb-1.5">{feature.title}</p>
      <p className="text-muted-foreground text-xs leading-relaxed">{feature.description}</p>
    </div>
  )
}

export default function Features() {
  // Duplicate for seamless loop
  const items = [...features, ...features]

  return (
    <section id="features" className="py-24 bg-background relative overflow-hidden">
      {/* Background glow */}
      <div
        className="absolute -top-32 -left-32 w-96 h-96 rounded-full pointer-events-none animate-glow-pulse"
        style={{ background: "radial-gradient(circle, rgba(0,82,204,0.05) 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-[#0052cc] font-semibold text-sm uppercase tracking-widest mb-3">
            Platform Features
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0a0f24] tracking-tight text-balance mb-4">
            Everything your business needs, in one platform
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Optimezo replaces a dozen disconnected tools with one unified ERP — purpose-built for Indian MSMEs.
          </p>
        </div>
      </div>

      {/* Marquee track — full bleed */}
      <div className="relative w-full overflow-hidden marquee-track">
        {/* Fade edges */}
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to right, white, transparent)" }}
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to left, white, transparent)" }}
          aria-hidden="true"
        />

        <div className="flex animate-marquee-slow pb-4" style={{ width: "max-content" }}>
          {items.map((feature, i) => (
            <FeatureCard key={`${feature.title}-${i}`} feature={feature} />
          ))}
        </div>
      </div>

      {/* Stats strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-14">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border rounded-2xl overflow-hidden border border-border">
          {[
            { value: "10,000+", label: "Businesses Onboarded" },
            { value: "₹5Cr+", label: "Transactions Processed" },
            { value: "99.9%",   label: "Platform Uptime" },
            { value: "8+",      label: "App Integrations" },
          ].map((stat) => (
            <div key={stat.label} className="bg-white px-6 py-8 text-center group hover:bg-[#0052cc]/5 transition-colors duration-300">
              <p className="text-3xl font-bold gradient-text mb-1">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
