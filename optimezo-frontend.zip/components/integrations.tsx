"use client"

import { ArrowRight } from "lucide-react"
import Image from "next/image"

// Real logo URLs from official CDNs / Wikipedia / simple-icons
const integrations = [
  {
    name: "WhatsApp",
    category: "Communication",
    logo: "https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg",
    bg: "#f0fdf4",
    color: "#25D366",
    description: "Automated order updates & customer notifications via WhatsApp Business API.",
  },
  {
    name: "Tally",
    category: "Accounting",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Tally_Solutions_logo.svg/512px-Tally_Solutions_logo.svg.png",
    bg: "#fff7ed",
    color: "#E55A2B",
    description: "Bi-directional sync for accounting, vouchers, ledgers, and GST data.",
  },
  {
    name: "Google Sheets",
    category: "Productivity",
    logo: "https://upload.wikimedia.org/wikipedia/commons/3/30/Google_Sheets_logo_%282014-2020%29.svg",
    bg: "#f0fdf4",
    color: "#0F9D58",
    description: "Export reports and sync data with Google Sheets in real time.",
  },
  {
    name: "Gmail",
    category: "Communication",
    logo: "https://upload.wikimedia.org/wikipedia/commons/7/7e/Gmail_icon_%282020%29.svg",
    bg: "#fff5f5",
    color: "#EA4335",
    description: "Auto-send GST invoices and order confirmations from your Gmail.",
  },
  {
    name: "Zoho CRM",
    category: "CRM",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Zoho_logo_%28new%29.png/512px-Zoho_logo_%28new%29.png",
    bg: "#fff5f5",
    color: "#E42527",
    description: "Sync contacts, deals, and pipeline stages for a unified view.",
  },
  {
    name: "AfterShip",
    category: "Logistics",
    logo: "https://www.aftership.com/favicon.ico",
    bg: "#eff6ff",
    color: "#1A56DB",
    description: "Track all shipments and auto-notify customers of delivery status.",
  },
  {
    name: "BUSY",
    category: "Accounting",
    logo: "https://www.busy.in/img/busy-logo.png",
    bg: "#f5f3ff",
    color: "#7C3AED",
    description: "Seamless financial data flow and GST reconciliation with BUSY.",
  },
  {
    name: "EasyCom",
    category: "E-Commerce",
    logo: "https://easyecom.io/wp-content/uploads/2023/01/EasyEcom-Logo.svg",
    bg: "#eff6ff",
    color: "#0052CC",
    description: "Sync multichannel e-commerce orders for unified fulfillment.",
  },
  {
    name: "Google Drive",
    category: "Storage",
    logo: "https://upload.wikimedia.org/wikipedia/commons/1/12/Google_Drive_icon_%282020%29.svg",
    bg: "#fffbeb",
    color: "#FBBC04",
    description: "Store and share documents, reports, and assets securely.",
  },
  {
    name: "Zapier",
    category: "Automation",
    logo: "https://upload.wikimedia.org/wikipedia/commons/f/fd/Zapier_logo.svg",
    bg: "#fff7ed",
    color: "#FF4A00",
    description: "Connect 5000+ apps through Zapier automation workflows.",
  },
  {
    name: "Slack",
    category: "Communication",
    logo: "https://upload.wikimedia.org/wikipedia/commons/d/d5/Slack_icon_2019.svg",
    bg: "#fdf4ff",
    color: "#4A154B",
    description: "Get business alerts and reports directly in your Slack channels.",
  },
  {
    name: "Shopify",
    category: "E-Commerce",
    logo: "https://upload.wikimedia.org/wikipedia/commons/0/0e/Shopify_logo_2018.svg",
    bg: "#f0fdf4",
    color: "#96BF48",
    description: "Sync Shopify orders, inventory, and customers with Optimezo.",
  },
]

function IntegrationPill({ item }: { item: (typeof integrations)[0] }) {
  return (
    <div
      className="flex-shrink-0 mx-3 group flex items-center gap-3 px-5 py-3.5 rounded-2xl bg-white border border-border hover:border-[#0052cc]/40 hover:shadow-lg hover:shadow-[#0052cc]/10 transition-all duration-300 hover:-translate-y-0.5 cursor-default select-none"
      style={{ minWidth: 200 }}
    >
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
        style={{ background: item.bg }}
      >
        <Image
          src={item.logo}
          alt={item.name}
          width={28}
          height={28}
          className="w-7 h-7 object-contain"
          unoptimized
        />
      </div>
      <div>
        <p className="font-semibold text-[#0a0f24] text-sm leading-none mb-1">{item.name}</p>
        <span
          className="text-[10px] font-medium px-1.5 py-0.5 rounded-full"
          style={{ background: `${item.color}18`, color: item.color }}
        >
          {item.category}
        </span>
      </div>
    </div>
  )
}

export default function Integrations() {
  const row1 = [...integrations.slice(0, 6), ...integrations.slice(0, 6)]
  const row2 = [...integrations.slice(6), ...integrations.slice(6)]

  return (
    <section id="integrations" className="py-24 bg-muted relative overflow-hidden">
      {/* Animated background accent */}
      <div
        className="absolute top-1/2 right-0 w-[500px] h-[500px] -translate-y-1/2 rounded-full pointer-events-none animate-float-slow"
        style={{ background: "radial-gradient(circle, rgba(0,82,204,0.05) 0%, transparent 70%)", animationDelay: "0.5s" }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="text-[#0052cc] font-semibold text-sm uppercase tracking-widest mb-3">
            Integrations
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0a0f24] tracking-tight text-balance mb-4">
            Connects with the tools you already use
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Optimezo integrates natively with 12+ platforms — no code, no complex setup. Just connect and go.
          </p>
        </div>
      </div>

      {/* Row 1 — left to right */}
      <div className="relative w-full overflow-hidden marquee-track mb-4">
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to right, oklch(0.96 0.005 264), transparent)" }}
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to left, oklch(0.96 0.005 264), transparent)" }}
          aria-hidden="true"
        />
        <div className="flex animate-marquee py-2" style={{ width: "max-content" }}>
          {row1.map((item, i) => (
            <IntegrationPill key={`r1-${item.name}-${i}`} item={item} />
          ))}
        </div>
      </div>

      {/* Row 2 — right to left */}
      <div className="relative w-full overflow-hidden marquee-track mb-12">
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to right, oklch(0.96 0.005 264), transparent)" }}
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-24 z-10"
          style={{ background: "linear-gradient(to left, oklch(0.96 0.005 264), transparent)" }}
          aria-hidden="true"
        />
        <div className="flex animate-marquee-reverse py-2" style={{ width: "max-content" }}>
          {row2.map((item, i) => (
            <IntegrationPill key={`r2-${item.name}-${i}`} item={item} />
          ))}
        </div>
      </div>

      {/* CTA strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 p-6 rounded-2xl bg-[#0a0f24] border border-white/10 relative overflow-hidden group">
          <div
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
            style={{ background: "linear-gradient(135deg, rgba(0,82,204,0.15) 0%, transparent 60%)" }}
            aria-hidden="true"
          />
          <div className="text-center sm:text-left relative z-10">
            <p className="text-white font-semibold text-base">Need a custom integration?</p>
            <p className="text-white/50 text-sm">We support 50+ apps via Zapier and our open API.</p>
          </div>
          <a
            href="#contact"
            className="flex-shrink-0 relative z-10 inline-flex items-center gap-2 px-6 py-2.5 bg-[#0052cc] hover:bg-[#003d99] text-white text-sm font-semibold rounded-xl transition-all hover:scale-105 hover:shadow-lg hover:shadow-[#0052cc]/30"
          >
            Talk to Sales <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  )
}
