'use client'

import { useState, useCallback } from 'react'
import { X } from 'lucide-react'
import AuthForm from '@/components/onboarding/auth-form'
import CompanySetup from '@/components/onboarding/company-setup'
import PlanSelection from '@/components/onboarding/plan-selection'
import ProvisioningScreen from '@/components/onboarding/provisioning-screen'

interface User {
  name: string
  email: string
  password: string
}

interface Company {
  name: string
  subdomain: string
}

type Step = 'auth' | 'company' | 'plan' | 'provisioning' | 'complete'

interface OnboardingModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function OnboardingModal({ isOpen, onClose }: OnboardingModalProps) {
  const [step, setStep] = useState<Step>('auth')
  const [authTab, setAuthTab] = useState<'signup' | 'signin'>('signup')
  const [user, setUser] = useState<User | null>(null)
  const [company, setCompany] = useState<Company | null>(null)
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'paid' | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleAuthSuccess = useCallback((userData: User) => {
    setUser(userData)
    setStep('company')
  }, [])

  const handleCompanySetup = useCallback((companyData: Company) => {
    setCompany(companyData)
    setStep('plan')
  }, [])

  const handlePlanSelected = useCallback((plan: 'free' | 'paid') => {
    setSelectedPlan(plan)
    setStep('provisioning')
    startProvisioning(plan)
  }, [])

  const startProvisioning = async (plan: 'free' | 'paid') => {
    setIsLoading(true)
    
    // TODO: Connect to backend APIs
    // 1. POST /api/auth/signup or signin - create user account
    // 2. POST /api/sites/create - provision workspace with company data
    // 3. GET subdomain.optimezo.com - redirect to new workspace
    
    try {
      // Simulate API call (3 second delay)
      await new Promise((resolve) => setTimeout(resolve, 3000))
      
      // In real implementation:
      // const response = await fetch('/api/sites/create', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({
      //     user,
      //     company,
      //     plan,
      //   }),
      // })
      // const { subdomain } = await response.json()
      
      setStep('complete')
      setIsLoading(false)
      
      // Simulate redirect after 1 second
      setTimeout(() => {
        const subdomain = company?.subdomain || 'workspace'
        window.location.href = `https://${subdomain}.optimezo.com`
      }, 1000)
    } catch (error) {
      console.error('Provisioning failed:', error)
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
        <div
          className="relative w-full max-w-[500px] bg-white rounded-xl shadow-2xl overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close Button */}
          {step !== 'provisioning' && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-lg transition-colors z-10"
              aria-label="Close onboarding"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          )}

          {/* Content */}
          <div className="p-8 md:p-10 min-h-[500px] flex flex-col">
            {step === 'auth' && (
              <AuthForm
                tab={authTab}
                onTabChange={setAuthTab}
                onSuccess={handleAuthSuccess}
              />
            )}

            {step === 'company' && user && (
              <CompanySetup onSuccess={handleCompanySetup} />
            )}

            {step === 'plan' && company && (
              <PlanSelection onSelectPlan={handlePlanSelected} />
            )}

            {step === 'provisioning' && company && (
              <ProvisioningScreen
                companyName={company.name}
                subdomain={company.subdomain}
              />
            )}

            {step === 'complete' && (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                  <svg
                    className="w-8 h-8 text-green-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-900">Redirecting...</h2>
                <p className="text-gray-600 text-center">
                  Your workspace is ready. Taking you there now.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
