import dynamic from 'next/dynamic'

const HeroDynamic = dynamic(() => import('@/components/hero'), {
  ssr: false,
  loading: () => <div className="min-h-screen bg-[#0a0f24]" />
})

interface HeroWrapperProps {
  onGetStarted?: () => void
}

export default function HeroWrapper({ onGetStarted }: HeroWrapperProps) {
  return <HeroDynamic onGetStarted={onGetStarted} />
}
