interface OptimezoLogoProps {
  className?: string
  /** height in px — width scales automatically */
  height?: number
  /** "light" = white wordmark for dark backgrounds (default), "dark" = charcoal wordmark */
  variant?: "light" | "dark"
}

export default function OptimezoLogo({
  className = "",
  height = 40,
  variant = "light",
}: OptimezoLogoProps) {
  const wordColor = variant === "light" ? "#ffffff" : "#0a0f24"
  const subColor  = variant === "light" ? "rgba(255,255,255,0.55)" : "rgba(10,15,36,0.5)"

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 220 48"
      height={height}
      aria-label="Optimezo"
      className={className}
      fill="none"
    >
      <defs>
        {/* Icon gradient — teal-to-blue */}
        <linearGradient id="oz-g1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"   stopColor="#00c6a7" />
          <stop offset="100%" stopColor="#0052cc" />
        </linearGradient>
        {/* Subtle inner glow */}
        <linearGradient id="oz-g2" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%"   stopColor="#0052cc" />
          <stop offset="100%" stopColor="#4fa8ff" />
        </linearGradient>
        <filter id="oz-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="1.4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* ── Icon mark (24×24, centered vertically at y=12..36) ── */}
      <g transform="translate(0, 12)" filter="url(#oz-glow)">
        {/* Outer ring arc — open at bottom-right */}
        <path
          d="M12 2 A10 10 0 1 1 21.8 17.5"
          stroke="url(#oz-g1)"
          strokeWidth="2.2"
          strokeLinecap="round"
          fill="none"
        />
        {/* Upward arrow through ring */}
        <path
          d="M18 20 L12 6 L6 20"
          stroke="url(#oz-g1)"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Inner horizontal bar */}
        <path
          d="M8.5 15.5 L15.5 15.5"
          stroke="url(#oz-g2)"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Small dot accent at arrow tip */}
        <circle cx="12" cy="5.5" r="1.2" fill="url(#oz-g1)" />
        {/* Arrow head on ring tail */}
        <path
          d="M21.8 17.5 L24 14.5 M21.8 17.5 L18.6 17.1"
          stroke="url(#oz-g1)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* ── Wordmark ── */}
      {/* "Optimezo" — Inter-style bold wordmark */}
      <text
        x="32"
        y="31"
        fontFamily="Inter, system-ui, sans-serif"
        fontSize="22"
        fontWeight="700"
        letterSpacing="-0.5"
        fill={wordColor}
      >
        Optimezo
      </text>

      {/* Thin accent rule under wordmark */}
      <rect x="32" y="35.5" width="62" height="1.5" rx="1" fill="url(#oz-g1)" opacity="0.7" />
    </svg>
  )
}
