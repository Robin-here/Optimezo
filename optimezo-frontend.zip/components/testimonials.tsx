"use client"

import { Star, Quote } from "lucide-react"
import { useState, useEffect, useRef } from "react"

const testimonials = [
  {
    name: "Rahul Mehta",
    role: "Founder, Mehta Textiles",
    location: "Surat, Gujarat",
    avatar: "RM",
    rating: 5,
    quote:
      "Optimezo transformed how we manage our textile business. The WhatsApp integration alone saves us 2 hours daily. Our order processing time dropped by 60%.",
    metric: "60% faster orders",
    color: "#0052cc",
  },
  {
    name: "Priya Sharma",
    role: "CEO, SparkTech Distributors",
    location: "Mumbai, Maharashtra",
    avatar: "PS",
    rating: 5,
    quote:
      "The GST invoicing and Tally sync are flawless. I no longer worry about reconciliation errors at month-end. Our accountant loves it too.",
    metric: "Zero reconciliation errors",
    color: "#7C3AED",
  },
  {
    name: "Anil Kumar",
    role: "Owner, AK Auto Parts",
    location: "Delhi, NCR",
    avatar: "AK",
    rating: 5,
    quote:
      "We manage 3 warehouses and 12 staff through Optimezo. The inventory alerts and AfterShip integration keep our customers happy and our team focused.",
    metric: "3 warehouses, 1 platform",
    color: "#0F9D58",
  },
  {
    name: "Sneha Patel",
    role: "Director, GreenFarm Organics",
    location: "Ahmedabad, Gujarat",
    avatar: "SP",
    rating: 5,
    quote:
      "The EasyCom integration was the game-changer. Our Amazon, Flipkart, and direct orders now flow into one system. Zero manual work.",
    metric: "All channels unified",
    color: "#E55A2B",
  },
  {
    name: "Vikram Joshi",
    role: "Co-Founder, TechWave Solutions",
    location: "Pune, Maharashtra",
    avatar: "VJ",
    rating: 5,
    quote:
      "We evaluated 5 ERP platforms. Optimezo was the only one that understood Indian MSME needs — GST, WhatsApp, BUSY sync. The onboarding was incredibly smooth.",
    metric: "Best-in-class onboarding",
    color: "#1A56DB",
  },
  {
    name: "Deepa Nair",
    role: "GM Operations, Kochi Crafts",
    location: "Kochi, Kerala",
    avatar: "DN",
    rating: 5,
    quote:
      "Our revenue visibility improved dramatically. The real-time analytics dashboard helps me make decisions in seconds, not days.",
    metric: "Real-time decisions",
    color: "#EA4335",
  },
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: rating }).map((_, i) => (
        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
      ))}
    </div>
  )
}

function FlipCard({ t, index }: { t: typeof testimonials[0]; index: number }) {
  const [flipped, setFlipped] = useState(false)
  const [visible, setVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true) },
      { threshold: 0.2 }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      className="perspective-1000"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transition: `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`,
      }}
    >
      <div
        className="relative h-72 cursor-pointer preserve-3d transition-transform duration-700"
        style={{ transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)" }}
        onClick={() => setFlipped((f) => !f)}
        onMouseEnter={() => setFlipped(true)}
        onMouseLeave={() => setFlipped(false)}
        role="button"
        tabIndex={0}
        aria-label={`Testimonial from ${t.name}. Click to flip.`}
        onKeyDown={(e) => e.key === "Enter" && setFlipped((f) => !f)}
      >
        {/* ── Front face ── */}
        <div className="absolute inset-0 backface-hidden rounded-2xl p-6 border border-border bg-card flex flex-col shadow-md hover:shadow-xl hover:shadow-[#0052cc]/8 transition-shadow duration-300 overflow-hidden">
          {/* Decorative top gradient bar */}
          <div
            className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
            style={{ background: `linear-gradient(90deg, ${t.color}, transparent)` }}
            aria-hidden="true"
          />

          <div className="flex items-start justify-between mb-3">
            <StarRating rating={t.rating} />
            <Quote className="w-6 h-6 opacity-10 text-[#0052cc] flex-shrink-0" aria-hidden="true" />
          </div>

          <blockquote className="flex-1 text-foreground text-sm leading-relaxed line-clamp-4">
            &ldquo;{t.quote}&rdquo;
          </blockquote>

          <figcaption className="mt-4 flex items-center gap-3 pt-4 border-t border-border">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0"
              style={{ background: t.color }}
            >
              {t.avatar}
            </div>
            <div>
              <p className="font-semibold text-[#0a0f24] text-sm">{t.name}</p>
              <p className="text-muted-foreground text-xs">{t.role}</p>
            </div>
          </figcaption>

          <p className="mt-2 text-center text-[10px] text-muted-foreground/50 tracking-wide">
            Hover to see highlight
          </p>
        </div>

        {/* ── Back face ── */}
        <div
          className="absolute inset-0 backface-hidden rotate-y-180 rounded-2xl p-6 border flex flex-col items-center justify-center text-center shadow-2xl overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${t.color}ee 0%, #0a0f24 100%)`,
            borderColor: `${t.color}44`,
          }}
        >
          {/* Animated rings */}
          <div
            className="absolute inset-0 rounded-2xl pointer-events-none"
            aria-hidden="true"
          >
            <div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-white/10 animate-spin-slow"
            />
            <div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-white/15"
              style={{ animation: "spin-slow 14s linear infinite reverse" }}
            />
          </div>

          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-white text-xl font-bold mb-4 relative z-10 shadow-lg"
            style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(6px)" }}
          >
            {t.avatar}
          </div>

          <p className="text-white font-bold text-lg mb-1 z-10 relative">{t.name}</p>
          <p className="text-white/70 text-xs mb-4 z-10 relative">{t.role} &bull; {t.location}</p>

          <div
            className="px-4 py-2 rounded-full z-10 relative"
            style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(4px)" }}
          >
            <p className="text-white font-semibold text-sm">{t.metric}</p>
          </div>

          <div className="mt-4 flex gap-0.5 z-10 relative">
            {Array.from({ length: t.rating }).map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-amber-300 text-amber-300" />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-muted overflow-hidden relative">
      {/* Subtle animated background blobs */}
      <div
        className="absolute top-0 right-0 w-80 h-80 rounded-full pointer-events-none animate-float-slow"
        style={{
          background: "radial-gradient(circle, rgba(0,82,204,0.06) 0%, transparent 70%)",
          animationDelay: "1s",
        }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-0 left-0 w-96 h-96 rounded-full pointer-events-none animate-float-mid"
        style={{
          background: "radial-gradient(circle, rgba(0,82,204,0.05) 0%, transparent 70%)",
          animationDelay: "0s",
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-[#0052cc] font-semibold text-sm uppercase tracking-widest mb-3">
            Customer Stories
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#0a0f24] tracking-tight text-balance mb-4">
            Trusted by MSMEs across India
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Over 10,000 businesses run on Optimezo. Hover each card to see their highlight.
          </p>
        </div>

        {/* 3D Flip cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <FlipCard key={t.name} t={t} index={i} />
          ))}
        </div>

        {/* Trust bar */}
        <div className="mt-14 flex flex-col sm:flex-row items-center justify-center gap-8 text-center">
          {[
            { label: "Average Rating", value: "4.9 / 5.0" },
            { label: "Verified Reviews", value: "2,400+" },
            { label: "Net Promoter Score", value: "72 NPS" },
          ].map((item, i) => (
            <div
              key={item.label}
              className="flex flex-col items-center animate-slide-up"
              style={{ animationDelay: `${i * 0.15}s` }}
            >
              <span className="text-2xl font-bold gradient-text">{item.value}</span>
              <span className="text-sm text-muted-foreground mt-0.5">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
