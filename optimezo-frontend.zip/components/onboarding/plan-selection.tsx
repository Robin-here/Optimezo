'use client'

import { useState } from 'react'
import { Check, Loader2 } from 'lucide-react'
import RazorpayCheckout from '@/components/onboarding/razorpay-checkout'

interface PlanSelectionProps {
  onSelectPlan: (plan: 'free' | 'paid') => void
}

const freeFeatures = [
  'Full Starter plan access',
  '15-day free trial',
  'Up to 10 users',
  '1 active website',
  'Basic reports',
  'Email support',
]

const paidFeatures = [
  'Growth plan access',
  '₹4,999/month (billed monthly)',
  'Up to 25 users',
  '3 active websites',
  'Advanced reports',
  'Priority support',
  'CRM & Projects module',
  'Multi-warehouse inventory',
]

export default function PlanSelection({ onSelectPlan }: PlanSelectionProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [showRazorpay, setShowRazorpay] = useState(false)

  const handleFreePlan = async () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      onSelectPlan('free')
    }, 300)
  }

  const handlePaidPlan = () => {
    setShowRazorpay(true)
  }

  const handleRazorpaySuccess = () => {
    setShowRazorpay(false)
    onSelectPlan('paid')
  }

  if (showRazorpay) {
    return (
      <RazorpayCheckout onSuccess={handleRazorpaySuccess} onCancel={() => setShowRazorpay(false)} />
    )
  }

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Choose your plan</h1>
        <p className="text-gray-600">
          Start free for 15 days or upgrade anytime. No credit card needed for the trial.
        </p>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Free Plan */}
        <div className="relative border-2 border-gray-200 rounded-xl p-6 hover:border-gray-300 transition-colors">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-gray-900 mb-1">Starter</h3>
            <p className="text-sm text-gray-600 mb-4">Perfect to get started</p>
            <div className="flex items-baseline gap-1 mb-2">
              <span className="text-sm text-gray-600">Free for</span>
              <span className="text-3xl font-bold text-gray-900">15 days</span>
            </div>
            <p className="text-xs text-gray-500">Then ₹2,499/month</p>
          </div>

          {/* Features List */}
          <div className="space-y-3 mb-8 pb-8 border-b border-gray-200">
            {freeFeatures.map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-gray-700">{feature}</span>
              </div>
            ))}
          </div>

          {/* Button */}
          <button
            onClick={handleFreePlan}
            disabled={isLoading}
            className="w-full py-2.5 border-2 border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-900 font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
            Start Free Trial
          </button>
        </div>

        {/* Paid Plan */}
        <div className="relative border-2 border-blue-600 rounded-xl p-6 bg-blue-50 shadow-lg shadow-blue-100">
          {/* Popular Badge */}
          <div className="absolute -top-3 left-6 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
            MOST POPULAR
          </div>

          <div className="mb-6 pt-2">
            <h3 className="text-xl font-bold text-gray-900 mb-1">Growth</h3>
            <p className="text-sm text-gray-600 mb-4">Best for growing teams</p>
            <div className="flex items-baseline gap-1 mb-2">
              <span className="text-sm text-gray-600">₹</span>
              <span className="text-3xl font-bold text-gray-900">4,999</span>
              <span className="text-sm text-gray-600">/month</span>
            </div>
            <p className="text-xs text-gray-500">Billed monthly</p>
          </div>

          {/* Features List */}
          <div className="space-y-3 mb-8 pb-8 border-b border-blue-200">
            {paidFeatures.map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-gray-700">{feature}</span>
              </div>
            ))}
          </div>

          {/* Button */}
          <button
            onClick={handlePaidPlan}
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
          >
            Start with Growth Plan
          </button>
        </div>
      </div>

      {/* Comparison Note */}
      <div className="text-center text-sm text-gray-600">
        <p>
          Not sure which plan? Both come with{' '}
          <span className="font-semibold">full access to core ERP features</span>. Upgrade or
          downgrade anytime.
        </p>
      </div>
    </div>
  )
}
