'use client'

import { useState, useCallback, useEffect } from 'react'
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react'

interface CompanySetupProps {
  onSuccess: (company: { name: string; subdomain: string }) => void
}

type ValidationStatus = 'idle' | 'checking' | 'available' | 'taken' | 'invalid'

export default function CompanySetup({ onSuccess }: CompanySetupProps) {
  const [companyName, setCompanyName] = useState('')
  const [subdomain, setSubdomain] = useState('')
  const [validationStatus, setValidationStatus] = useState<ValidationStatus>('idle')
  const [isLoading, setIsLoading] = useState(false)

  // Auto-generate subdomain from company name
  const generateSubdomain = useCallback((name: string) => {
    if (!name) {
      setSubdomain('')
      return
    }
    const generated = name
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '')
      .substring(0, 50)

    setSubdomain(generated)
    setValidationStatus('idle')
  }, [])

  const handleCompanyNameChange = (value: string) => {
    setCompanyName(value)
    generateSubdomain(value)
  }

  // Validate subdomain
  const validateSubdomain = useCallback(async (value: string) => {
    if (!value) {
      setValidationStatus('idle')
      return
    }

    // Client-side validation
    if (!/^[a-z0-9-]+$/.test(value)) {
      setValidationStatus('invalid')
      return
    }

    if (value.length < 3) {
      setValidationStatus('invalid')
      return
    }

    setValidationStatus('checking')

    // TODO: Connect to backend
    // const response = await fetch(`/api/subdomain/check?subdomain=${value}`)
    // const { available } = await response.json()
    // setValidationStatus(available ? 'available' : 'taken')

    // Simulate API check (most subdomains are available)
    await new Promise((resolve) => setTimeout(resolve, 600))
    setValidationStatus('available')
  }, [])

  const handleSubdomainChange = (value: string) => {
    // Only allow lowercase, numbers, and hyphens
    const filtered = value
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, '')

    setSubdomain(filtered)
    validateSubdomain(filtered)
  }

  const handleContinue = async () => {
    if (!companyName.trim()) {
      return
    }

    if (validationStatus !== 'available') {
      return
    }

    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 500))
    setIsLoading(false)

    onSuccess({
      name: companyName,
      subdomain,
    })
  }

  const isValid = companyName.trim() && validationStatus === 'available'

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Create your workspace
        </h1>
        <p className="text-gray-600">
          Give your company a name and choose your workspace URL
        </p>
      </div>

      {/* Form */}
      <div className="space-y-6">
        {/* Company Name */}
        <div>
          <label htmlFor="company" className="block text-sm font-medium text-gray-900 mb-2">
            Company Name
          </label>
          <input
            id="company"
            type="text"
            value={companyName}
            onChange={(e) => handleCompanyNameChange(e.target.value)}
            placeholder="e.g., Acme Inc"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
          />
          <p className="text-xs text-gray-500 mt-1">
            This is the name displayed in your workspace
          </p>
        </div>

        {/* Subdomain */}
        <div>
          <label htmlFor="subdomain" className="block text-sm font-medium text-gray-900 mb-2">
            Workspace URL
          </label>
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
                <span className="px-4 py-2 text-gray-600 font-medium bg-gray-50 border-r border-gray-300 whitespace-nowrap">
                  https://
                </span>
                <input
                  id="subdomain"
                  type="text"
                  value={subdomain}
                  onChange={(e) => handleSubdomainChange(e.target.value)}
                  placeholder="mycompany"
                  className="flex-1 px-4 py-2 focus:outline-none"
                />
                <span className="px-4 py-2 text-gray-600 font-medium bg-gray-50 border-l border-gray-300 whitespace-nowrap">
                  .optimezo.com
                </span>
              </div>

              {/* Validation Status */}
              <div className="mt-2">
                {validationStatus === 'checking' && (
                  <div className="flex items-center gap-2 text-blue-600 text-xs">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Checking availability...
                  </div>
                )}
                {validationStatus === 'available' && (
                  <div className="flex items-center gap-2 text-green-600 text-xs">
                    <CheckCircle2 className="w-3 h-3" />
                    This URL is available
                  </div>
                )}
                {validationStatus === 'taken' && (
                  <div className="flex items-center gap-2 text-red-600 text-xs">
                    <AlertCircle className="w-3 h-3" />
                    This URL is already taken
                  </div>
                )}
                {validationStatus === 'invalid' && (
                  <div className="flex items-center gap-2 text-red-600 text-xs">
                    <AlertCircle className="w-3 h-3" />
                    Only lowercase letters, numbers, and hyphens. Minimum 3 characters.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Preview */}
          {subdomain && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-gray-600 mb-1">Your workspace will be available at:</p>
              <p className="text-sm font-mono font-semibold text-blue-600">
                https://{subdomain}.optimezo.com
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Continue Button */}
      <button
        onClick={handleContinue}
        disabled={!isValid || isLoading}
        className="w-full py-3 mt-8 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
      >
        {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
        Continue to Plans
      </button>
    </div>
  )
}
