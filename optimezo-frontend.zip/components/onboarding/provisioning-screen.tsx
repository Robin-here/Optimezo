'use client'

import { useEffect, useState } from 'react'

interface ProvisioningScreenProps {
  companyName: string
  subdomain: string
}

const steps = [
  { label: 'Creating account', duration: 600 },
  { label: 'Setting up database', duration: 800 },
  { label: 'Configuring workspace', duration: 700 },
  { label: 'Finalizing setup', duration: 500 },
]

export default function ProvisioningScreen({
  companyName,
  subdomain,
}: ProvisioningScreenProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    let elapsedTime = 0

    steps.forEach((step, index) => {
      setTimeout(() => {
        setCurrentStep(index + 1)
      }, elapsedTime)

      elapsedTime += step.duration
    })

    // Animate progress bar
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + Math.random() * 15
        return Math.min(newProgress, 90)
      })
    }, 300)

    // Complete at the end
    setTimeout(() => {
      setProgress(100)
      clearInterval(interval)
    }, elapsedTime)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-full flex flex-col items-center justify-center py-12">
      {/* Animated Icon */}
      <div className="mb-8">
        <div className="relative w-20 h-20">
          {/* Outer rotating ring */}
          <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-blue-600 border-r-blue-400 animate-spin" />

          {/* Inner pulsing circle */}
          <div className="absolute inset-2 rounded-full bg-blue-50 flex items-center justify-center animate-pulse">
            <div className="w-6 h-6 rounded-full bg-blue-600" />
          </div>
        </div>
      </div>

      {/* Main Message */}
      <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">
        Setting up your workspace
      </h2>
      <p className="text-gray-600 text-center mb-2">
        We're creating your account and provisioning your site at
      </p>
      <p className="text-lg font-semibold text-blue-600 mb-8">
        https://{subdomain}.optimezo.com
      </p>

      {/* Progress Bar */}
      <div className="w-full mb-8">
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-600 to-blue-400 transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-xs text-gray-500 mt-2 text-center">{Math.round(progress)}%</p>
      </div>

      {/* Steps */}
      <div className="space-y-3 w-full max-w-xs">
        {steps.map((step, index) => (
          <div
            key={index}
            className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
              index < currentStep
                ? 'bg-green-50 text-green-900'
                : index === currentStep
                  ? 'bg-blue-50 text-blue-900'
                  : 'bg-gray-50 text-gray-600'
            }`}
          >
            {/* Status Icon */}
            <div
              className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                index < currentStep
                  ? 'bg-green-600 text-white'
                  : index === currentStep
                    ? 'bg-blue-600 text-white animate-pulse'
                    : 'bg-gray-300 text-gray-600'
              }`}
            >
              {index < currentStep ? (
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                index + 1
              )}
            </div>

            <span className="text-sm font-medium">{step.label}</span>
          </div>
        ))}
      </div>

      {/* Tip */}
      <p className="text-xs text-gray-500 text-center mt-8 max-w-xs">
        This usually takes about 30 seconds. You'll be redirected shortly.
      </p>
    </div>
  )
}
