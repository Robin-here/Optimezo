'use client'

import { useState } from 'react'
import { X, Loader2, Lock, Check } from 'lucide-react'

interface RazorpayCheckoutProps {
  onSuccess: () => void
  onCancel: () => void
}

export default function RazorpayCheckout({ onSuccess, onCancel }: RazorpayCheckoutProps) {
  const [step, setStep] = useState<'summary' | 'payment' | 'processing'>('summary')
  const [cardNumber, setCardNumber] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [cvv, setCvv] = useState('')
  const [cardName, setCardName] = useState('')

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!cardNumber || !expiryDate || !cvv || !cardName) {
      return
    }

    setStep('processing')

    // TODO: Connect to Razorpay API
    // const response = await fetch('/api/payment/razorpay', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({
    //     amount: 499900, // ₹4,999 in paise
    //     currency: 'INR',
    //     description: 'Optimezo Growth Plan',
    //     card: { cardNumber, expiryDate, cvv },
    //   }),
    // })
    // const { success } = await response.json()

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))
    onSuccess()
  }

  return (
    <div className="w-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Checkout</h2>
      </div>

      {step === 'summary' && (
        <>
          {/* Order Summary */}
          <div className="bg-gray-50 rounded-lg p-6 mb-8 border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Order Summary</h3>

            <div className="space-y-3 mb-4 pb-4 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Growth Plan (Monthly)</span>
                <span className="font-semibold text-gray-900">₹4,999</span>
              </div>
              <div className="flex justify-between items-center text-sm text-gray-600">
                <span>Tax (0%)</span>
                <span>₹0</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-semibold text-gray-900">Total Amount</span>
              <span className="text-2xl font-bold text-blue-600">₹4,999</span>
            </div>

            <p className="text-xs text-gray-600 mt-4">
              Your subscription will renew on the same date every month. Cancel anytime from your settings.
            </p>
          </div>

          {/* Features */}
          <div className="mb-8">
            <h3 className="font-semibold text-gray-900 mb-4">You will get access to:</h3>
            <ul className="space-y-2">
              {[
                'Up to 25 users',
                '3 active websites',
                'CRM & Projects',
                'Multi-warehouse inventory',
                'Advanced reports',
                'Priority support',
              ].map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-green-600" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          {/* Buttons */}
          <div className="space-y-3">
            <button
              onClick={() => setStep('payment')}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
            >
              Proceed to Payment
            </button>
            <button
              onClick={onCancel}
              className="w-full py-2 border border-gray-300 hover:bg-gray-50 text-gray-900 font-semibold rounded-lg transition-colors"
            >
              Back to Plans
            </button>
          </div>
        </>
      )}

      {step === 'payment' && (
        <>
          {/* Payment Form */}
          <form onSubmit={handlePaymentSubmit} className="space-y-5 mb-6">
            {/* Cardholder Name */}
            <div>
              <label htmlFor="cardName" className="block text-sm font-medium text-gray-900 mb-2">
                Cardholder Name
              </label>
              <input
                id="cardName"
                type="text"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                placeholder="John Doe"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Card Number */}
            <div>
              <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-900 mb-2">
                Card Number
              </label>
              <input
                id="cardNumber"
                type="text"
                value={cardNumber}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '').slice(0, 16)
                  setCardNumber(value)
                }}
                placeholder="4532 1234 5678 9010"
                maxLength={16}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            {/* Expiry & CVV */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="expiry" className="block text-sm font-medium text-gray-900 mb-2">
                  Expiry (MM/YY)
                </label>
                <input
                  id="expiry"
                  type="text"
                  value={expiryDate}
                  onChange={(e) => {
                    let value = e.target.value.replace(/\D/g, '').slice(0, 4)
                    if (value.length >= 2) {
                      value = value.slice(0, 2) + '/' + value.slice(2)
                    }
                    setExpiryDate(value)
                  }}
                  placeholder="12/25"
                  maxLength={5}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>
              <div>
                <label htmlFor="cvv" className="block text-sm font-medium text-gray-900 mb-2">
                  CVV
                </label>
                <input
                  id="cvv"
                  type="text"
                  value={cvv}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 3)
                    setCvv(value)
                  }}
                  placeholder="123"
                  maxLength={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="space-y-3 pt-4">
              <button
                type="submit"
                disabled={!cardNumber || !expiryDate || !cvv || !cardName}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Lock className="w-4 h-4" />
                Pay ₹4,999
              </button>
              <button
                type="button"
                onClick={() => setStep('summary')}
                className="w-full py-2 border border-gray-300 hover:bg-gray-50 text-gray-900 font-semibold rounded-lg transition-colors"
              >
                Back
              </button>
            </div>

            {/* Security Note */}
            <p className="text-xs text-gray-600 text-center flex items-center justify-center gap-1">
              <Lock className="w-3 h-3" />
              This is a secure, demo payment form. Powered by Razorpay.
            </p>
          </form>
        </>
      )}

      {step === 'processing' && (
        <div className="flex flex-col items-center justify-center py-12 gap-4">
          <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center animate-pulse">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Processing Payment...</h3>
          <p className="text-sm text-gray-600 text-center">
            Please wait while we confirm your payment. This usually takes a few seconds.
          </p>
        </div>
      )}
    </div>
  )
}
