'use client'

import { useState } from 'react'
import Header from "@/components/header"
import HeroWrapper from "@/components/hero-wrapper"
import Features from "@/components/features"
import Integrations from "@/components/integrations"
import Pricing from "@/components/pricing"
import Testimonials from "@/components/testimonials"
import Contact from "@/components/contact"
import Footer from "@/components/footer"
import OnboardingModal from "@/components/onboarding-modal"

export default function PageClient() {
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false)

  return (
    <main>
      <Header onGetStarted={() => setIsOnboardingOpen(true)} />
      <HeroWrapper onGetStarted={() => setIsOnboardingOpen(true)} />
      <Features />
      <Integrations />
      <Pricing onGetStarted={() => setIsOnboardingOpen(true)} />
      <Testimonials />
      <Contact />
      <Footer />
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
      />
    </main>
  )
}
