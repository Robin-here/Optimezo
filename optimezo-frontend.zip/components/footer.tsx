import Link from "next/link"
import OptimezoLogo from "@/components/optimezo-logo"

const footerLinks = {
  Product: [
    { label: "Features", href: "#features" },
    { label: "Integrations", href: "#integrations" },
    { label: "Pricing", href: "#pricing" },
    { label: "Changelog", href: "#" },
    { label: "Roadmap", href: "#" },
  ],
  Company: [
    { label: "About Us", href: "#" },
    { label: "Blog", href: "#" },
    { label: "Careers", href: "#" },
    { label: "Press Kit", href: "#" },
    { label: "Contact", href: "#contact" },
  ],
  Resources: [
    { label: "Documentation", href: "#" },
    { label: "API Reference", href: "#" },
    { label: "Help Center", href: "#" },
    { label: "Status Page", href: "#" },
    { label: "Community", href: "#" },
  ],
  Legal: [
    { label: "Privacy Policy", href: "#" },
    { label: "Terms of Service", href: "#" },
    { label: "Cookie Policy", href: "#" },
    { label: "GDPR", href: "#" },
  ],
}

const socials = [
  { label: "LinkedIn", href: "#", letter: "in" },
  { label: "Twitter / X", href: "#", letter: "𝕏" },
  { label: "YouTube", href: "#", letter: "YT" },
  { label: "WhatsApp", href: "#", letter: "WA" },
]

export default function Footer() {
  return (
    <footer className="bg-[#0a0f24] text-white">
      {/* CTA Banner */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white text-balance mb-2">
              Ready to simplify your business?
            </h2>
            <p className="text-white/50 text-base">
              Join 10,000+ MSMEs already running on Optimezo.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <Link
              href="#contact"
              className="px-7 py-3 bg-[#0052cc] hover:bg-[#003d99] text-white font-semibold text-sm rounded-xl transition-all text-center shadow-lg shadow-[#0052cc]/30"
            >
              Get Started Free
            </Link>
            <Link
              href="#"
              className="px-7 py-3 bg-white/8 hover:bg-white/14 text-white font-semibold text-sm rounded-xl border border-white/15 hover:border-white/30 transition-all text-center"
            >
              Login to Dashboard
            </Link>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-10">
          {/* Brand column */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-flex items-center mb-5" aria-label="Optimezo home">
              <OptimezoLogo height={36} variant="light" />
            </Link>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-xs">
              The most powerful cloud ERP and integration platform built for Indian MSMEs and growing businesses.
            </p>
            {/* Socials */}
            <div className="flex gap-2.5">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="w-9 h-9 rounded-lg bg-white/8 hover:bg-[#0052cc] flex items-center justify-center text-white/60 hover:text-white text-xs font-bold transition-all"
                >
                  {s.letter}
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <p className="text-white font-semibold text-sm mb-4">{category}</p>
              <ul className="flex flex-col gap-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-white/50 hover:text-white text-sm transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-white/40">
          <p>© {new Date().getFullYear()} Optimezo Technologies Pvt. Ltd. All rights reserved.</p>
          <p>Made with ❤️ in India 🇮🇳</p>
        </div>
      </div>
    </footer>
  )
}
